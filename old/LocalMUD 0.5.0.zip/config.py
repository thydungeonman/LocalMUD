# config.py

import random
from datetime import datetime


CURRENT_MOTD = "Welcome to LocalMUD. The chapel awaits."
VERSION = "v0.5.0 — The Great Refactor"
DEV_NOTE = "This build is focused on splitting the code to make room for growth."


MOTD_LIST = [
    "Welcome to LocalMUD. The chapel awaits.",
    "The ladle remembers.",
    "You feel watched, but not judged.",
    "A hero arises. Will it be you?",
    "The altar hums with forgotten power.",
    "The orb hums with quiet energy.",
    "A chill wind whispers through the eastern passage.",
    "You feel watched, though no one is near.",
    "The dust seems freshly disturbed...",
    "Something ancient stirs beneath the chapel.",
    "To the death mug of doom!",
    "The spoon is missing. Again.",
    "You awaken with the taste of ash and memory.",
    "The chapel doors creak, though no wind blows.",
    "A ladle once saved your life. You never thanked it.",
    "The candles flicker in Morse code. You don't speak Morse.",
    "You are not the first to enter. You may not be the last.",
    "The orb pulses. It knows your name.",
    "A whisper echoes: 'Inventory is empty. So is your soul.'",
    "The pews are warm. Someone was just here.",
    "You remember a dream about soup. It felt important.",
    "The shadows stretch longer than they should.",
    "The floorboards groan. They remember your weight.",
    "You feel cursed. Statistically, you might be.",
    "The ladle is watching. Always watching.",
    "You hear a distant clatter. It might be spoons.",
    "The chapel is quiet. Too quiet.",
    "A single word is etched into the wall: 'WHY?'",
    "You feel like you're being narrated."
]

#You can rotate rare entries by using weighted random choices later
#Some could be tied to player stats or curse count in future versions
#Want to add seasonal or event-based MOTDs? Easy to modularize!

SEASONAL_MOTDS = {
    "halloween": [
        "The pumpkins whisper secrets.",
        "You hear a ghostly ladle clatter in the dark.",
        "The chapel is dressed in cobwebs. You hope they're decorative."
    ],
    "winter": [
        "Snow falls silently through the broken roof.",
        "You feel warmth, but the fire is long dead.",
        "The orb glows like a frosted lantern."
    ],
    "birthday": [
        "The ladle bows to you. It knows what day it is.",
        "A single candle flickers atop the altar. Happy Birthday, Alex.",
        "You feel unusually powerful. The chapel senses your birthright.",
        "The orb pulses in celebration. It’s your day.",
        "The pews hum a quiet tune. It sounds like a birthday song."
    ]
}


def get_motd(debug=False):
    today = datetime.now()
    month = today.month
    day = today.day

    seasonal = []
    source = "standard"

    # Birthday: March 6
    if month == 3 and day == 6:
        seasonal.extend(SEASONAL_MOTDS["birthday"])
        source = "birthday"

    # Halloween: Oct 25–31
    elif month == 10 and day >= 25:
        seasonal.extend(SEASONAL_MOTDS["halloween"])
        source = "halloween"

    # Winter: Dec 20–Jan 5
    elif (month == 12 and day >= 20) or (month == 1 and day <= 5):
        seasonal.extend(SEASONAL_MOTDS["winter"])
        source = "winter"

    pool = MOTD_LIST + seasonal
    motd = random.choice(pool)

    if debug:
        print(f"[DEBUG] MOTD Source: {source}")
        print(f"[DEBUG] Selected MOTD: {motd}")

    return motd


