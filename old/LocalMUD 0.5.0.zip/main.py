import curses
import copy
from rooms import rooms
from items import items
from player import player as initial_player
from parser import handle_command
from config import get_motd
from ui import show_intro, show_game_over_menu, draw_ui

def launch(stdscr):
    # Outer loop lets us restart without exiting the program
    while True:
        # ——— Init per‐run state ———
        game_state = {
            "current_room": (0, 0, 0, "chapel"),
            "game_over": False,
            "restart": False
        }

        # Deep-copy so each run is fresh
        player = copy.deepcopy(initial_player)

        current_motd = get_motd()
        message_log = []

        # Show the intro screen, passing in the MOTD
        show_intro(stdscr, current_motd)

        # Enter main game loop
        main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log)

        # Break out entirely unless player chose “Restart”
        if not game_state.get("restart"):
            break

def main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log):
    curses.curs_set(1)
    stdscr.nodelay(False)

    while True:
        draw_ui(stdscr, game_state, player, rooms, message_log)

        # Recalculate screen size after draw_ui
        height, width = stdscr.getmaxyx()
        input_y = height - 2
        stdscr.addstr(input_y, 2, "> ")
        stdscr.refresh()
            
        # ─── Input Prompt ───
        input_y = height - 2
        stdscr.addstr(input_y, 2, "> ")
        stdscr.refresh()

        # Get user command
        curses.echo()
        try:
            raw = stdscr.getstr(input_y, 4, width - 6).decode().strip()
        except Exception:
            raw = ""
        curses.noecho()

        if raw:
            message_log.append(f"> {raw}")

        # Run parser
        result = handle_command(raw, game_state, player, rooms, items, current_motd)

        # Handle parser output
        if isinstance(result, list):
            message_log.extend(result)
        elif isinstance(result, str):
            if result == "quit":
                message_log.append("Thanks for playing LocalMUD!")
                break
            else:
                message_log.append(result)
        message_log.append("")

        # ─── Check for Game Over ───
        if game_state.get("game_over"):
            choice = show_game_over_menu(stdscr, player)
            if choice == "restart":
                game_state["restart"] = True
                break
            elif choice == "load":
                message_log.append("Load feature not implemented yet.")
                game_state["game_over"] = False
            elif choice == "quit":
                break

if __name__ == "__main__":
    curses.wrapper(launch)
