# player.py

player = {
    "name": "Hero",
    "location": (0, 0, 0, "chapel"),
    "inventory": [],
    "hp": 6,
    "max_hp": 6,
    "ac": 7,  # Armor Class (descending) lower is better
    "str": 13, #Melee attack bonuys, Carry Weight
    "dex": 9, #AC Bonus, Ranged Attack Bonus
    "con": 12, #HP Bonus Per Level
    "int": 10, #Spell Learning
    "wis": 8, #Saving Throws, Divine Magic
    "cha": 11, #npc reactions, hirelings
    "level": 1, 
    "xp": 0,
    "status": [],
    "flags": {},
    "curse_count": 0  # Added for dirty word tracking
}
