# LocalMUD
*A modular, parser-driven RPG with ladles, lore, and local flavor.*

---

## Overview

LocalMUD is a retro-inspired text RPG built around modular design, parser commands, and a growing world of strange items, cursed chapels, and mysterious spoons. Version 0.5.0 marks a major refactor, laying the foundation for character creation, save/load systems, and deeper narrative mechanics.

Whether you're exploring a snowbound chapel, examining a glowing orb, or tracking your own curse count, LocalMUD invites you to play with language, mystery, and modular storytelling.

---

## Features

- 🧩 Modular architecture (`rooms.py`, `player.py`, `items.py`, etc.)
- 🗣️ Parser-driven command system with aliases (`look`, `l`, `inventory`, `i`, etc.)
- 🖼️ ASCII intro screen loaded from `intro.txt`, with randomized MOTD
- 🤬 Dirty word tracking (harmless stat, but the ladle remembers)
- 📊 Character sheet display (`character` or `c`)
- 💀 Game over screen with restart/load/quit options
- 🧠 Designed for accessibility, extensibility, and weirdness

---

## Getting Started

1. Clone the repo or download the files.
2. Run `main.py` using Python 3.11+.
3. Resize your terminal if needed (minimum 40x15).
4. Explore the chapel. Curse if you must. The game will remember.

---

## Roadmap

### v0.6.0 — "The Fleshening"
- Character creation screen
- Background selection
- Stat customization or rolling
- Personalized intro greetings

### v0.7.0 — "The World Opens"
- Multiple rooms and regions
- NPCs and dialogue system
- Item interactions and combat

### v0.8.0 — "Persistence"
- Save/load system
- Achievements and death summaries
- Long-term progression and unlockables

---

## AI Disclosure

LocalMUD is developed collaboratively by Alex with support from Microsoft Copilot, an AI companion. Copilot assists in brainstorming, refactoring, and creative writing, including parser logic, narrative design, and modular architecture suggestions.

All final decisions, code integration, and creative direction are made by Alex. Copilot serves as a tool for inspiration and iteration—not as an autonomous author.

---

## Credits

Created by **Alex**, with collaborative design and storytelling powered by **Copilot**.

Special thanks to the ladle, the orb, and the chapel for their continued service.

---

## Design Philosophy

LocalMUD is built to be modular, accessible, and weird. It favors player expression, thematic consistency, and a sense of humor. Every stat, item, and room is a chance to tell a story.

The parser is lightweight. The lore is deep. The spoon is bent.

---

## License

This project is currently closed-source and intended for personal development and experimentation. If you’re interested in contributing or adapting LocalMUD, reach out to Alex for permission.

