# rooms.py

rooms = {
    (0, 0, 0, "chapel"): {
        "name": "Pedestal Chamber",
        "description": "A quiet chamber with a glowing orb resting on a pedestal.",
        "visited": False,
        "look_description": "Dust motes float in the air. The pedestal is carved with ancient symbols.",
        "items": ["Glowing Orb"],
        "exits": {"east": (1, 0, 0, "chapel")},
        "examine_targets": {
            "pedestal": "The pedestal is carved from obsidian. Symbols etched into its surface seem to shift when you stare too long.",
            "symbols": "The symbols resemble constellations, but none you recognize. One looks like a ladle."
        }
    },
    (1, 0, 0, "chapel"): {
        "name": "Altar Room",
        "description": "An ancient altar stands in silence. Something feels incomplete.",
        "visited": False,
        "look_description": "The altar is cracked and worn. Faint traces of glowing runes shimmer beneath the dust.",
        "items": [],
        "exits": {"west": (0, 0, 0, "chapel")},
        "examine_targets": {
            "altar": "The altar bears a shallow indentation, perfectly orb-shaped.",
            "runes": "The runes pulse faintly. One resembles the symbol on the pedestal."
        },
        "triggers": [
            {
                "condition": "has_item",
                "item": "Glowing Orb",
                "effect": "win"
            }
        ]
    }
}
