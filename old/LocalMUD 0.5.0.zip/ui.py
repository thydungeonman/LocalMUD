# ui.py

import curses

def show_intro(stdscr, motd):
    stdscr.clear()

    # Try to load intro.txt
    try:
        with open("intro.txt", "r", encoding="utf-8") as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                stdscr.addstr(i, 2, line.rstrip())
            motd_y = len(lines) + 2
    except FileNotFoundError:
        stdscr.addstr(1, 2, "Welcome to LocalMUD!")
        motd_y = 5

    # Display MOTD and prompt
    stdscr.addstr(motd_y, 2, f"MOTD: {motd}")
    stdscr.addstr(motd_y + 2, 2, "Press any key to begin...")
    stdscr.refresh()
    stdscr.getch()




def show_game_over_menu(stdscr, player):
    stdscr.clear()
    stdscr.addstr(1, 2, "💀 GAME OVER 💀")
    stdscr.addstr(3, 2, f"Name: {player['name']}")
    stdscr.addstr(4, 2, f"Level: {player['level']}")
    stdscr.addstr(5, 2, f"HP: 0 / {player['max_hp']}")
    stdscr.addstr(6, 2, f"Cause of Death: TBD")
    if player.get("curse_count", 0) > 0:
        stdscr.addstr(8, 2, f"Curse Count: {player['curse_count']} (tsk tsk)")
    stdscr.addstr(10, 2, "[R]estart  [L]oad  [Q]uit")
    stdscr.refresh()

    while True:
        key = stdscr.getkey().lower()
        if key == "r":
            return "restart"
        elif key == "l":
            return "load"
        elif key == "q":
            return "quit"

def draw_ui(stdscr, game_state, player, rooms, message_log):
    stdscr.clear()
    curses.curs_set(1)

    height, width = stdscr.getmaxyx()

    # Minimum size check
    if height < 15 or width < 40:
        stdscr.addstr(0, 0, "Window too small. Please resize.")
        stdscr.refresh()
        return

    # ─── Top Bar ───
    title = "LocalMUD"
    hp = player["hp"]
    max_hp = player["max_hp"]
    orb_status = "Carried" if "Glowing Orb" in player["inventory"] else "Missing"
    top_bar = f"{title} — HP: {hp}/{max_hp} | Orb: {orb_status}"
    stdscr.addstr(0, 2, top_bar[: width - 4])

    # ─── Room Info ───
    room = rooms[game_state["current_room"]]
    stdscr.addstr(2, 2, f"Location: {room['name']}"[: width - 4])
    stdscr.addstr(3, 2, room["description"][: width - 4])

    # ─── Message Log ───
    max_lines = height - 7
    visible = message_log[-max_lines:]
    for idx, line in enumerate(visible):
        stdscr.addstr(5 + idx, 2, line[: width - 4])

    stdscr.refresh()
