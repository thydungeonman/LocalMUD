# Changelog

All notable changes to this project will be documented in this file.

GOALS:

-Create a help command for each parser command
-Fix Help Parser Command
-Change game header to show XP
-Add XP when going to new rooms.
-Start trying to build a tiny mini map.
-when you go to a new room for the first time, it should roll the description in the log.

-Start work on a player creation module.

-Switch MOTD to actually give you a different message each day instead of only when the program opens.
	-April 1st easter egg? Enable airplane sounds mode?
	-Birthday message
	-Christmas message

For blind players:

1. Offer a Non-Curses Mode
Create a fallback mode that uses print() and input() instead of curses. This ensures compatibility with screen readers.

python
if accessibility_mode:
    print("Location: Pedestal Chamber")
    print("Dust motes float in the air...")
    command = input("> ")
You could trigger this with a launch flag or a startup prompt:

text
Enable screen reader mode? [Y/N]
v0.6.0 — "The Fleshening"




## [0.6.0] — "The Fleshening" — 2025-07-18

### Added
- [System] Introduced `character.py` to manage character creation logic. Not to be confused with `player.py`, which stores the base player template and non-stat defaults.
- [Core] Implemented a character generation sequence triggered at launch: name entry, stat rolling, class/background selection, and HP assignment.
- [World] Intro paragraph now displays upon entering the chapel, establishing tone and player motivation.
- [Parser] Added `title` command to return to the title screen with confirmation prompt.

### Changed
- [Dev Experience] Added verbose comment headers to all modules for improved clarity and onboarding.
- [UI] Updated top bar to reflect character's actual HP values post-creation.

---

## [0.5.0] — "The Great Refactor" — 2025-07-17

### Added
- [System] `rooms.py` now holds all room data.
- [System] `player.py` now holds all player stat data.
- [System] `items.py` now holds all item data.
- [System] `parser.py` now holds all command and parser logic.
- [System] `config.py` now centralizes configurable constants and metadata.
- [System] `ui.py` now holds all UI code.
- [Parser] Added a dirty word filter that tracks curse usage and logs it as a harmless statistic in the character sheet.
- [Parser] Added a `character` command to display player stats. Also works with just `C`.
- [UI] Added a game over screen with restart/load/quit options.

### Changed
- [System] Trimmed down the functionality crammed into `main.py`, delegating to modular files.
- [Parser] `inventory` command now also works with `I`.
- [Parser] `examine` command now also works with `X`.
- [Parser] `look` command now also works with `L`.
- [System] Retired `MOTD.txt` in favor of centralized MOTD handling in `config.py`.
- [System] MOTD logic now lives in `config.py`, with seasonal and birthday support.
- [UI] Intro screen now displays MOTD with proper reverence.
- [Flavor] The ladle now celebrates Halloween, winter, and Alex’s birthday.

---

## [0.4.0] — "A Hero Arises" — 2025-07-16

### Added
- [Parser] Added 'Examine' command to the parser allowing the user to examine items in thier possesion as well as objects in the room.
- [System] Added a verbose description propery to each item that can only be seen by using the examine command.
- [World] Room data now supports examinable environmental objects, enriching world detail and interactivity.

### Changed
- [UI] Refined spacing and layout for cleaner message log readability and improved input/output flow.
- [Player] Expanded player data to include a full OSR-style stat block, laying groundwork for future combat and progression.
- [World] Rooms now track whether they’ve been visited, enabling exploration-based logic and flavor.
- [System] Room coordinates upgraded from (x, y) to (x, y, z, instance), supporting multi-level maps and alternate realities.
- [Feature] MOTD now dynamically selected at launch from a curated list in the `config.py` file.
- [Dev Note] Refactor complete. Codebase now modular, scalable, and easier to maintain.
- [Parser] Fixed the previously broken quit command.

---

## [0.3.0] — "Orb Awakens" — 2025-07-15

### Added
- [Parser] Added 'HELP' and 'ABOUT' commands to the parser.
- [UI] Added a splash screen when starting LocalMUD
- [UI] Added message of the day to startup splash screen which pulls from MOTD.txt

### Changed
- [UI] Updated the layout to resemble a scrolling chat log with a static top bar, inspired by Infocom games.
- [Parser] Fixed the 'use' command so the orb is now usable.
- [System] Separated the orb item logic from the parser; items are now modular.
- [UI] Expanded 'go' command to support shorthand inputs like 'e', 'east', or standalone direction commands.

### Removed
- [System] Removed the dev instance. It made more trouble than it was preventing.
- [UI] Removed constant inventory display from the interface.

---

## [0.2.0] — "Looking Clearly" — 2025-07-14

### Added
- [World] Added 'look_description' to rooms for richer environmental detail.
- [Parser] Made the 'look' command dynamically list exits and items in the room.

### Changed
- [UI] Improved window resizing behavior for better layout stability.

### Development
- [System] Created a development instance (main_dev.py) for testing changes.

---

## [0.1.0] — "In the beginning, there was nothingness." — 2025-07-12

### Added
- [Core] Built the first playable prototype: two rooms, a parser, and a collectable item.

### Setup
- [System] Established the project using Python and a console-based interface.
