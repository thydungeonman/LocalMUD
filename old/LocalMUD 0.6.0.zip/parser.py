# parser.py
"""
LocalMUD — Command Parser

Handles all player input and command logic. Supports aliases, dirty word tracking,
and command routing to appropriate game functions.

Typical usage:
- Called during main game loop to interpret input
- Interacts with player, rooms, and items modules

Author: Alex

Dev Notes:
- Keep command logic modular—each command should be easy to isolate and test.
- Aliases should be intuitive and documented.
- Consider adding command history or auto-complete in future UI upgrades.
"""

from character import CORE_STATS, get_modifier, roll_stats
from config import VERSION, DEV_NOTE


DIRECTION_ALIASES = {
    "n": "north",
    "north": "north",
    "s": "south",
    "south": "south",
    "e": "east",
    "east": "east",
    "w": "west",
    "west": "west"
}

COMMANDS = [
    "look",
    "go [direction]",
    "take [item]",
    "use [item]",
    "inventory (or i)",
    "examine [item or object]",
    "character (or c)",
    "about",
    "motd",
    "clear",
    "help",
    "title",
    "quit"
]

DIRTY_WORDS = ["shit", "fuck", "ass"]

def handle_command(command, game_state, player, rooms, items, current_motd):
    output = []
    room = rooms[game_state["current_room"]]
    tokens = command.lower().split()

    tokens = command.lower().split()

    # Dirty word filter
    for word in tokens:
        if word in DIRTY_WORDS:
            player["curse_count"] += 1
            return [
                "Let's try to keep it clean.",
                "The narrator sighs and adjusts your character sheet."
            ]
            

    if not tokens:
        return "No command entered."
        

    elif tokens[0] == "go":
        if len(tokens) > 1:
            dir_input = tokens[1].lower()
            direction = DIRECTION_ALIASES.get(dir_input)
            if direction and direction in room["exits"]:
                new_room = room["exits"][direction]
                game_state["current_room"] = new_room
                player["location"] = new_room
                rooms[new_room]["visited"] = True  # Mark room as visited
                return [f"You go {direction}."]
            else:
                return [f"You can't go that way."]
        else:
            return ["Go where?"]
        
    elif tokens[0] in ['examine', 'e']:
        target = " ".join(tokens[1:]).lower()

        # Check inventory first
        for item in player["inventory"]:
            if item.lower() == target:
                item_data = items.get(item)
                if item_data:
                    return item_data.get("examine_text", f"You examine the {item}, but find nothing unusual.")

        # Check room examine targets
        examine_targets = room.get("examine_targets", {})
        if target in examine_targets:
            return examine_targets[target]

        return "You see nothing special."


    elif tokens[0] in DIRECTION_ALIASES:
        direction = DIRECTION_ALIASES[tokens[0]]
        if direction in room["exits"]:
            new_room = room["exits"][direction]
            game_state["current_room"] = new_room
            player["location"] = new_room
            rooms[new_room]["visited"] = True
            return [f"You go {direction}."]
        else:
            return [f"You can't go that way."]
            
    elif tokens[0] == "about":
        return [
            f"LocalMUD {VERSION}",
            DEV_NOTE
        ]
    
    elif command == "title":
        output.append("Are you sure you want to return to the title screen? [Y]es / [N]o")
        return "confirm_title"

    
    elif command in ["character", "c"]:
        output.append(f"Name: {player.get('name', 'Unknown')}")
        output.append(f"Background: {player.get('background', 'None')}")

        stats = player.get("stats", {})
        modifiers = player.get("modifiers", {})

        output.append("Stats:")
        for stat in CORE_STATS:
            value = stats.get(stat, 0)
            mod = modifiers.get(stat, 0)
            output.append(f"  {stat}: {value} ({mod:+d})")

        # Show curse count if greater than 0
        curse_count = player.get("curse_count", 0)
        if curse_count > 0:
            output.append(f"Curses: {curse_count}")



    elif tokens[0] == "help":
        help_lines = ["Available commands:"]
        for cmd in COMMANDS:
            help_lines.append(f"- {cmd}")
        return help_lines

     
    elif tokens[0] == "clear":
        message_log.clear()
        return ["Screen cleared."]

    elif tokens[0] == "motd":
        return [f"MOTD: {current_motd}"]

    elif tokens[0] == "take":
        item = " ".join(tokens[1:])
        for room_item in room["items"]:
            if room_item.lower() == item.lower():
                player["inventory"].append(room_item)
                room["items"].remove(room_item)
                return f"You take the {room_item}."
        return "That item isn't here."
       
    elif tokens[0] == "use":
        item_name = " ".join(tokens[1:])
        for inv_item in player["inventory"]:
            if inv_item.lower() == item_name.lower():
                item_data = items.get(inv_item)
                if item_data and "use" in item_data:
                    use_data = item_data["use"]
                    if use_data.get("location") == player["location"]:
                        effect = use_data.get("effect")
                        message = use_data.get("message", f"You use the {inv_item}.")
                        if effect == "win":
                            return message
                        elif effect == "unlock":
                            # Example: set a flag or modify room state
                            rooms[player["location"]]["flags"] = {"door_unlocked": True}
                            return message
                    else:
                        return f"You can't use the {inv_item} here."
                return f"You use the {inv_item}, but nothing happens."
        return "You don't have that item."

    elif tokens[0] in ["look", "l"]:
        look_parts = []

        # Base description
        look_text = room.get("look_description", room["description"])
        look_parts.append(look_text)

        # Items
        if room["items"]:
            look_parts.append("Items here: " + ", ".join(room["items"]))
        else:
            look_parts.append("There are no items here.")

        # Exits
        exit_texts = {
            "north": "an exit north",
            "east": "an exit east",
            "west": "an exit west",
            "south": "an exit south"
        }
        exits = room.get("exits", {})
        exit_descriptions = [exit_texts.get(dir, dir) for dir in exits]
        if exit_descriptions:
            look_parts.append("Exits: " + ", ".join(exit_descriptions))

        return look_parts




    elif tokens[0] in ["inventory", "i"]:
        if not player["inventory"]:
            return "Your inventory is empty."
        lines = ["You are carrying:"]
        for item in player["inventory"]:
            desc = items.get(item, {}).get("description", "")
            lines.append(f"- {item}: {desc}")
        return "\n".join(lines)


    elif tokens[0] in ["quit", "exit"]:
        return "quit"

    else:
        return "Unknown command."
        
    return output