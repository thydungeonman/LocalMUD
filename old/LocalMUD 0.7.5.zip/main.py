import curses
import copy
import random
from rooms import rooms, npcs
from items import items
from player import player as initial_player
from parser import handle_command, verify_room_links
from config import get_motd, VERSION, DEV_NOTE
from ui import show_title_screen, show_game_over_menu, draw_ui, wrap_text, show_settings_menu 
from character import create_character, get_eligible_classes, get_modifier

 

def return_to_title(stdscr):
    curses.flash()
    stdscr.clear()
    launch(stdscr)  # Restart the game loop
            
def launch(stdscr):
    # Outer loop lets us restart without exiting the program
    while True:

        # ——— Init per‐run state ———
        game_state = {
            "current_room": (0, 0, 0, "chapel"),
            "game_over": False,
            "restart": False
        }

        current_motd = get_motd()
        message_log = []

        # Create initial player object before title screen
        player = {
            "name": "",
            "background": "",
            "hp": 10,
            "max_hp": 10,
            "xp": 0,
            "inventory": [],
            "location": (0, 0, 0, "chapel"),
            "max_hp_bonus": False
        }

        # Show title screen and allow settings access
        choice = show_title_screen(stdscr, current_motd, player)

        if choice == "quit":
            return
        elif choice == "new":
            # Proceed to character creation
            stdscr.clear()
            stdscr.addstr(20, 2, "Press any key to begin character creation...")
            stdscr.refresh()
            stdscr.getkey()

            # Apply optional HP bonus if enabled
            if player.get("max_hp_bonus"):
                player["max_hp"] += 5
                player["hp"] = player["max_hp"]

            # Create customized player
            player = create_character(stdscr, player)

            # Define and roll the intro text
            intro_text = [
                "The chapel is dusty and quiet. Its silence feels safe—but not empty. The air is thick with memory. Spirits rest here, but their posture is unclear. You are either being welcomed... or warned.",
                "The country of Eldermere cannot be allowed to fall. Somewhere in these walls lies the answer. The Oracle lived many lifetimes ago. If anyone still knows the path, it is him.",
                "There must be a way to reach him. The time for answers is now."
            ]

            height, width = stdscr.getmaxyx()

            verify_room_links(rooms)

            for paragraph in intro_text:
                wrapped_lines = wrap_text(paragraph, width - 4)
                message_log.extend(wrapped_lines)
                message_log.append("")

            # Enter main game loop
            main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log, npcs)

            if not game_state.get("restart"):
                break

def handle_idle_npc_actions(current_room, npcs, message_log):
    present_npcs = npcs.get(current_room, [])
    for npc in present_npcs:
        idle_lines = npc.get("idle_actions", [])
        if idle_lines and random.random() < 0.25:  # 25% chance to trigger
            message_log.append(random.choice(idle_lines))
            
def main_loop(stdscr, game_state, player, rooms, items, current_motd, message_log, npcs):
    curses.curs_set(1)
    stdscr.nodelay(False)

    while True:
        draw_ui(stdscr, game_state, player, rooms, message_log)

        # Recalculate screen size after draw_ui
        height, width = stdscr.getmaxyx()
        input_y = height - 2
        stdscr.addstr(input_y, 2, "> ")
        stdscr.refresh()

        # ─── Input Prompt ───
        input_y = height - 2
        stdscr.addstr(input_y, 2, "> ")
        stdscr.refresh()

        # Get user command
        curses.echo()
        try:
            raw = stdscr.getstr(input_y, 4, width - 6).decode().strip()
        except Exception:
            raw = ""
        curses.noecho()

        if raw:
            message_log.append(f"> {raw}")

        # Run parser
        result = handle_command(raw, game_state, player, rooms, items, current_motd, message_log)

        # Handle parser output
        if isinstance(result, list):
            message_log.extend(result)
        elif isinstance(result, str):
            if result == "quit":
                message_log.append("Thanks for playing LocalMUD!")
                break
            else:
                message_log.append(result)
        message_log.append("")

        # ─── Check for NPC Idle Actions ───
        # If player remains in a room, occasionally show ambient NPC behavior
        handle_idle_npc_actions(game_state["current_room"], npcs, message_log)

        # ─── Return to Title Command ───
        if result == "confirm_title":
            stdscr.clear()
            stdscr.addstr(5, 4, "Return to title screen? [Y]es / [N]o")
            stdscr.refresh()

            key = stdscr.getkey().lower()
            if key == "y":
                return_to_title(stdscr)
            else:
                message_log.append("Return canceled.")

        # ─── Check for Game Over ───
        if game_state.get("game_over"):
            choice = show_game_over_menu(stdscr, player)
            if choice == "restart":
                game_state["restart"] = True


if __name__ == "__main__":
    curses.wrapper(launch)
